package ma.ac.esi.referentielCompetences.model;

public class User {
	String login;
	String password;
//constructeur	
public User(String login, String password) {
        this.login = login;
        this.password = password;
    }

//Ajoutez un constructeur vide à la classe User pour pouvoir l'instancier sans paramètres.
public User() {
}
    
    // Getters et setters
    public String getLogin() {
        return login;
    }
    
    public void setLogin(String login) {
        this.login = login;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
	

    
}
