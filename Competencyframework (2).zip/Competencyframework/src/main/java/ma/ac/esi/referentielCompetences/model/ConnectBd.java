package ma.ac.esi.referentielCompetences.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectBd {

	private Connection connection;

    public ConnectBd() {
      
        try {
        	
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1/database" , "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public User FindUser(String login, String password) {
        User user = null;
        String query = "SELECT * FROM table WHERE login = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, login);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                
                user = new User(resultSet.getString("login"), resultSet.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

}
    	